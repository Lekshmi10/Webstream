/**
 * ADLoginSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.federal.checklist.loginsso;

public interface ADLoginSoap extends java.rmi.Remote {
    public com.federal.checklist.loginsso.UserAttributesResponseUserAttributesResult userAttributes(java.lang.String username, java.lang.String password) throws java.rmi.RemoteException;
}
