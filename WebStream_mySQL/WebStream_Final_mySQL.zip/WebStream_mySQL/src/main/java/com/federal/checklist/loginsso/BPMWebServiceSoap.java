/**
 * BPMWebServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.federal.checklist.loginsso;

public interface BPMWebServiceSoap extends java.rmi.Remote {
    public com.federal.checklist.loginsso.BPMData getUserDetails(java.lang.String username) throws java.rmi.RemoteException;
}
